﻿using Fantas;
using System.Drawing;

namespace ProjectName
{
    /// <summary>
    /// Main Game - main game object
    /// </summary>
    public class MainGame : Game
    {
        /// <summary>
        /// Preferred Window Size
        /// </summary>
        public static readonly Size PreferredSize = new Size(960, 540);

        /// <summary>
        /// MainGame ctor
        /// </summary>
        public MainGame() : base(PreferredSize, GameOptions.None)
        {

        }

        /// <summary>
        /// 
        /// </summary>
        public override void WindowSizeChanged()
        {
            if (WindowSize.Width < WindowSize.Height)
                CurrentScene.Size = new SizeF(PreferredSize.Height, PreferredSize.Width);
            else
                CurrentScene.Size = PreferredSize;
        }
    }
}
