﻿
using System;
using System.Drawing;

using Fantas;
using Fantas.Input;

namespace Project
{
    /// <summary>
    /// Main Scene 
    /// </summary>
    public class MainScene : Scene
    {
        private CameraNode camera;
        private RectangleNode border;

        /// <summary>
        /// Load content - will load all the nodes from the scene
        /// </summary>
        public override void Start()
        {
            camera = new CameraNode();

            Camera = camera;

            AddChild(camera);

            var square = new SpriteNode(Color.White, new Size(300, 300))
            {
                TopLeftColor = Color.Blue,
                TopRightColor = Color.Red,
                BottomLeftColor = Color.Yellow,
                BottomRightColor = Color.Green
            };

            border = new RectangleNode(Size)
            {
                Alpha = 0.5f,
                FillColor = Color.Transparent,
                StrokeColor = Color.Purple,
                LineWidth = 10
            };

            camera.AddChild(border);

            var label = new LabelNode()
            {
                Text = "Fantas",
                TopColor = Color.Red,
                BottomColor = Color.Yellow,
                Outline = true
            };

            square.AddChild(label);

            square.RunAnimation(Animation.RepeatForever(Animation.RotateBy(Math.PI, 2.0)));

            AddChild(square);
        }

        /// <summary>
        /// ctor
        /// </summary>
        public MainScene() : base(MainGame.PreferredSize)
        {
            BackgroundColor = Color.Brown;
        }

        /// <summary>
        /// 
        /// </summary>
        public override void Update()
        {
            if (MouseInput.IsLeftButtonDown)
            {
                BackgroundColor = Color.Brown;
            }
            else
            {
                BackgroundColor = Color.CornflowerBlue;
            }
            
            if (KeyboardInput.IsKeyDown(Keys.Escape))
                Environment.Exit(0);
        }

        /// <summary>
        /// Called when scene size changes
        /// </summary>
        public override void SizeChanged()
        {
            border.Size = Size;
        }
    }
}
